WATERCLIENT JAVA
================

Uruchom: URUCHOM.bat

Program korzysta z config.ini w folderze nadrzędnym (WATERCLIENT (2)), więc zachowuje ustawienia obecnego skryptu. Obsługuje Minecraft, bindy klawiatury i boczne przyciski myszy, waterskill, OCR Y na żywo, podgląd małego okna, kopanie A/D oraz A-W-D-S i tryb tła.

Pierwsze uruchomienie:
1. Wpisz nazwę użytkownika.
2. Podaj ten sam klucz licencyjny, którego używasz w starym WATERCLIENT.
3. Wybierz okno Minecrafta.
4. Zaznacz linię XYZ z F3 w zakładce AUTO po Y i kliknij TEST OCR.
5. Ustawienia zapisuje przycisk ZAPISZ. END zatrzymuje wszystkie akcje.

Wymagane jest 64-bitowe środowisko Java 8 lub nowsze. Na tym komputerze wykryto 64-bitową Javę 8, więc nie trzeba instalować kolejnej Javy, jeśli URUCHOM.bat znajduje ją przez PATH.
Podgląd DWM wymaga, aby okno Minecrafta nie było zminimalizowane.
