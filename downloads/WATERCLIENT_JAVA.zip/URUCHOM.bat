@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "JAVA_EXE="
if exist "%ProgramFiles%\Java\jre1.8.0_471\bin\java.exe" set "JAVA_EXE=%ProgramFiles%\Java\jre1.8.0_471\bin\java.exe"
if not defined JAVA_EXE (
  for /d %%D in ("%ProgramFiles%\Java\jre*") do if exist "%%~fD\bin\java.exe" set "JAVA_EXE=%%~fD\bin\java.exe"
)
if not defined JAVA_EXE (
  echo Nie znaleziono 64-bitowej Javy 8.
  echo Zainstaluj Java 8 x64 i uruchom ten plik ponownie.
  pause
  exit /b 1
)
echo Uruchamiam WATERCLIENT przez: "%JAVA_EXE%"
"%JAVA_EXE%" -cp "waterclient-java-1.0.jar;lib/*" WaterClient
if errorlevel 1 pause
